<?php 
$db = mysql_connect('localhost','root','');
if(!$db){
	die('Baza bilan aloqa yo`q'.mysql_error());
}
else{
	mysql_select_db('lang',$db);
}
	mysql_query("SET NAMES cp1251");
	  session_start();

?>