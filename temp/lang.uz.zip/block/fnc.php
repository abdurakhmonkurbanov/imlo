<?php
function repp($word){
	$word = str_replace(".","",$word);
	$word = str_replace(",","",$word);
	$word = str_replace("?","",$word);
	$word = str_replace("!","",$word);
	$word = str_replace(":","",$word);
	$word = str_replace(";","",$word);
	$word = str_replace("("," ",$word);
	$word = str_replace(")"," ",$word);
	$word = str_replace("'","`",$word);
	
	return($word);
}
function appostr($s){
	$s = str_replace("'","&#39;",$s);
	return($s);
}
function query($word){
	$i = 0;
	$s1 = "(`word` like '";
	$s2 = "') or ";
	$qu = "SELECT *  FROM `words` WHERE ".$s1.$word.$s2;
	for($i = 0;$i<strlen($word);$i++){
		$w1 = $word;
		$w1[$i] = '_';
		$qu = $qu.$s1.$w1.$s2;
	}
	for($i = 0;$i<strlen($word)-1;$i++){
		$w1 = $word;
		$w1[$i] = '_';
		$w1[$i+1] = '_';
		$qu = $qu.$s1.$w1.$s2;
	}
	for($i = 0;$i<strlen($word)+1;$i++){
		$w1 = substr($word,0,$i);
		$w2 = substr($word,$i,strlen($word));
		$w = $w1.'_'.$w2;
		$qu = $qu.$s1.$w.$s2;
	}
	$qu1 = substr($qu,0,strlen($qu)-3);
	return $qu1;
}


function endsWith( $str, $sub ) {
    return ( substr( $str, strlen( $str ) - strlen( $sub ) ) == $sub );
}

?>














