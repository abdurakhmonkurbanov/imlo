<?php
include('block/db.php');
include('block/fnc.php');
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <!-- Required meta tags always come first -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Imloviy tekshirish</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="cssjs/all.css">
  <!-- Bootstrap core CSS -->
  <link href="cssjs/bootstrap.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="cssjs/mdb.css" rel="stylesheet">
  <style>
  /* Required for full background image */

  html,
  body,
  header,
  .view {
    height: 100%;
  }
	  .yuk{
		  text-decoration: underline;
		  color: #ED0D10;

	  }
	  .bitta{
		  color: #000000;
	  }
	  .tugri{
			color: #000000;
	  }
	  .kup{
		  color: #0DE40B;
		  cursor: pointer;
	  }

  @media (max-width: 740px) {
    html,
    body,
    header,
    .view {
      height: 1000px;
    }
  }
  @media (min-width: 800px) and (max-width: 850px) {
    html,
    body,
    header,
    .view {
      height: 650px;
    }
  }

  .top-nav-collapse {
    background-color: #3f51b5 !important;
  }

  .navbar:not(.top-nav-collapse) {
    background: transparent !important;
  }

  @media (max-width: 991px) {
    .navbar:not(.top-nav-collapse) {
      background: #3f51b5 !important;
    }
  }

  .rgba-gradient {
    background: -webkit-linear-gradient(45deg, rgba(0, 0, 0, 0.7), rgba(72, 15, 144, 0.4) 100%);
    background: -webkit-gradient(linear, 45deg, from(rgba(0, 0, 0, 0.7), rgba(72, 15, 144, 0.4) 100%));
    background: linear-gradient(to 45deg, rgba(0, 0, 0, 0.7), rgba(72, 15, 144, 0.4) 100%);
  }

  .card {
    background-color: rgba(126, 123, 215, 0.2);
  }

  .md-form label {
    color: #ffffff;
  }

  h6 {
    line-height: 1.7;
  }
  </style>
<style type="text/css">/* Chart.js */
@-webkit-keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}@keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}.chartjs-render-monitor{-webkit-animation:chartjs-render-animation 0.001s;animation:chartjs-render-animation 0.001s;}</style></head>

<body aria-busy="true">
  <!-- Main navigation -->
	<header>
  <?php
	include('block/top.php');
	?>
		<?php
	include('block/body.php');
	?>
		
  <!-- Main navigation -->
  <!--Main Layout-->
	</header>
  <main>
    <div class="container">
      <!--Grid row-->
      <div class="row py-2">
        <!--Grid column-->
        <div class="col-md-12 text-justify">		
        <?php
		if (isset($_POST['txt'])){
			$txt = $_POST['txt'];
			$txt = explode(" ",$txt);
			$i = 0;
			
			 
			foreach($txt as $word){
				
				$word = repp($word);
				//echo query($word);
				//echo "---------------<br>";
				$wdb = mysql_query("select * from `words` where `word` like '$word'");
				$mwdb = mysql_fetch_array($wdb);
				if ($mwdb['word'] != ''){
					$jword[$i][0] = $word;
					$jword[$i][1] = $mwdb['word'];
					
				}
				else{
					$w2db = mysql_query(query($word));
					$num = mysql_num_rows($w2db);
					if ($num == 1) {
						$mw2db = mysql_fetch_array($w2db);
						$jword[$i][0] = $word;
						$jword[$i][1] = $mw2db['word'];
					}
					else {
						$jword[$i][0] = $word;
						$j = 1;
							while($mw2db = mysql_fetch_array($w2db)){
								$jword[$i][0] = $word;
								$jword[$i][$j] = $mw2db['word'];
								$j++;
								
							}
						}
					
				}
				$i++;
			}
			?>
		<script>
			var jword =[
				<?php
			$ln = count($jword);
			for($i = 0; $i < $ln;$i++){
				//print_r($jword[$i]);
				echo "[";
				foreach ($jword[$i] as $w){
					echo '"'.$w.'",';
				}
				echo "],
				";
			}
				?>
				];
			
					
			</script>
			<?php
		}	
			
			?>

			
         <br>
			<?php
			$ln = count($jword);
			for($i = 0; $i <= $ln;$i++){
				//print_r($jword[$i]);
				if ($jword[$i][1] == ''){
					echo (" <span class='yuk'>".$jword[$i][0]."</span> ");
					if (endsWith($jword[$i][0],'ga')){
						echo 'xa';
					}
					else echo 'yoq';
				}
				
				if ((count($jword[$i])==2) and (strtolower($jword[$i][0]) == $jword[$i][0] )){
					echo (" <span class='tugri'>".$jword[$i][1]." </span> ");
				}
				
				if ((count($jword[$i])==2) and (strtolower($jword[$i][0]) != $jword[$i][0] )){
					echo (" <span class='bitta'>".$jword[$i][0]." </span> ");
				}
				
				if (count($jword[$i])>2){
					?>
					  <div class="btn-group">
					<span class="kup  dropdown-toggle" id="kup<?php echo($i);?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo($jword[$i][0]) ;?> 
					</span>
  						<div class="dropdown-menu" aria-labelledby="kup<?php echo($i) ;?>">
			<?php
					foreach ($jword[$i] as $val){
						?>
							<a class="dropdown-item" onClick='javascript:kup(<?php echo($i) ;?>,"<?php echo(appostr($val)) ;?>");'><?php echo($val) ;?></a>
							<?php 
					}
					echo('</div></div>');
 
				}
			}
			
			?>
         <script>
			function kup(id,word){
				kid = 'kup'+id;
				document.getElementById(kid).innerHTML = word;
				
			}					
							
							
		</script>
				<a onClick=""			 
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->
    </div>
  </main>
  <!--Main Layout-->
  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="cssjs/jquery-3.js"></script>
  <!-- Tooltips -->
  <script type="text/javascript" src="cssjs/popper.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="cssjs/bootstrap.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="cssjs/mdb.js"></script>
	<div class="hiddendiv common"></div>
  <script>
  new WOW().init();
  </script>


</body></html>